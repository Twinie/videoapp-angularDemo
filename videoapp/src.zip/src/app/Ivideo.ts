export interface IVideo {
    Id:number;
    Title:string;
    Length:number;
    Category:string;
    Format:string;
}
