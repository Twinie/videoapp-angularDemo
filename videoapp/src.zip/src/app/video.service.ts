import {Injectable} from '@angular/core';
import { IVideo } from './Ivideo';

@Injectable({providedIn:'root'})

export class VideoService{
    getVidoes():IVideo[]{
        return[
            {
              "Id":1,
              "Title":"Azure",
              "Length":200,
              "Category":"Cloud Computing",
              "Format":"WMV"
            },
            {
              "Id":2,
              "Title":"Block Chain",
              "Length":180,
              "Category":"Block Chain dev",
              "Format":"MP4"
            },
            {
              "Id":3,
              "Title":"ReactJS",
              "Length":220,
              "Category":"Client Side Dev",
              "Format":"MP4"
            }
          ];
    }

}